#ifndef GLOBAL_H
#define GLOBAL_H
#define _XOPEN_SOURCE 500

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

#include "decode_and_log.h"

#endif
