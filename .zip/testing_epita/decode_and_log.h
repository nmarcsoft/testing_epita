#ifndef DECODE_AND_LOG_H
#define DECODE_AND_LOG_H

#include "global.h"

int decode_and_log(FILE *file);

#endif
